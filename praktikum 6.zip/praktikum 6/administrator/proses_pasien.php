<?php

require_once './db_koneksi.php';

// tangkap data from
$_kode = $_POST['Kode'];
$nama = $_POST['nama'];
$tmp_lahir = $_POST['tmp_lahir'];
$tgl_lahir = $_POST['tgl_lahir'];
$gender = $_POST['gender'];
$kelurahan_id = $_POST['kelurahan'];
$email = $_POST['email'];
$alamat = $_POST['alamat'];

//simpan data kedalam array
$data_id = [$_kode, $nama, $tmp_lahir, $tgl_lahir, $gender, $kelurahan_id, $email, $alamat];

// check nilai proses
switch ($_POST['proses']) {
    case 'Simpan':
        // membuat sql
        $insertPasienSQL = "INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, kelurahan_id, email, alamat) VALUES (?,?,?,?,?,?,?,?)";
        // mendefinisikan
        $stmt = $dbh->prepare($insertPasienSQL);
        //eksekusi 
        $stmt->execute($data_id);
        break;
    case 'Ubah':
        // Logic Mengubah Data
        break;
    case 'Hapus':
        //Logic menghapus data
        break;
    default:
        header('location: ./data_pasien.php');
}

// redirect
header('location: ./data_pasien.php');
