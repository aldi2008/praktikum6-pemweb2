<?php

require_once './db_koneksi.php';

$data_kelurahan = $dbh->query("SELECT * FROM kelurahan ORDER BY nama ASC");

$pasien_id = $_GET['id'] ?? 0;
if ($pasien_id) {
    $findPasienSQL = "SELECT * FROM pasien WHERE id = $pasien_id LIMIT 1";
    $pasien = $dbh->query($findPasienSQL);
    if ($pasien->rowCount()) $pasien = $pasien->fetch();
    else header('location: ./data_pasien.php');
}

include_once './layouts/top.php';
include_once './layouts/navbar.php';
include_once './layouts/sidebar.php';

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pasien</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Tambah Pasien</h3>
            </div>
            <div class="card-body">
                <form method="post" action="proses_pasien.php">
                    <div class="form-group row">
                        <label for="Kode" class="col-3 col-form-label">Kode</label>
                        <div class="col-9">
                            <input id="Kode" name="Kode" type="text" class="form-control" value="<?= $pasien['kode'] ?? '' ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-3 col-form-label">Nama Lengkap</label>
                        <div class="col-9">
                            <input id="nama" name="nama" type="text" class="form-control" value="<?= $pasien['nama'] ?? '' ?>">
                        </div>
                    </div>
                    <div class=" form-group row">
                        <label for="tmp_lahir" class="col-3 col-form-label">Tempat Lahir</label>
                        <div class="col-9">
                            <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control" value="<?= $pasien['tmp_lahir'] ?? '' ?>">
                        </div>
                    </div>
                    <div class=" form-group row">
                        <label for="tgl_lahir" class="col-3 col-form-label">Tanggal Lahir</label>
                        <div class="col-9">
                            <input id="tgl_lahir" name="tgl_lahir" type="date" class="form-control" value="<?= $pasien['tgl_lahir'] ?? '' ?>">
                        </div>
                    </div>
                    <div class=" form-group row">
                        <label class="col-3">Jenis Kelamin</label>
                        <div class="col-9">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="gender" id="gender_0" type="radio" class="custom-control-input" value="L" checked>
                                <label for="gender_0" class="custom-control-label">Laki-Laki</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="gender" id="gender_1" type="radio" class="custom-control-input" value="P" <?= $pasien_id && $pasien['gender'] == 'P' ? 'checked' : '' ?>>
                                <label for="gender_1" class="custom-control-label">Perempuan</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="kelurahan" class="col-3 col-form-label">Kelurahan</label>
                        <div class="col-9">
                            <select id="kelurahan" name="kelurahan" class="custom-select">
                                <option value="" disabled selected>--- Pilih Kelurahan ---</option>
                                <?php foreach ($data_kelurahan as $key => $kelurahan) : ?>
                                    <option <?= $pasien_id && $pasien['kelurahan_id'] ==  $kelurahan['id'] ? 'selected' : '' ?> value="<?= $kelurahan['id'] ?>"><?= $kelurahan['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-3 col-form-label">Email</label>
                        <div class="col-9">
                            <input id="email" name="email" type="email" class="form-control" value="<?= $pasien['email'] ?? '' ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="alamat" class="col-3 col-form-label">Alamat</label>
                        <div class="col-9">
                            <textarea id="alamat" name="alamat" cols="40" rows="2" class="form-control"><?= $pasien['alamat'] ?? '' ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="offset-3 col-9">
                            <input type="submit" name="proses" class="btn btn-primary" id="proses" value="<?= $pasien_id ? 'Uban' : 'Simpan' ?>">
                            <!-- <button name="submit" type="submit" class="btn btn-primary">Tambah Pasien</button> -->
                        </div>
                    </div>
                </form>

            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<?php include_once './layouts/bottom.php'; ?>